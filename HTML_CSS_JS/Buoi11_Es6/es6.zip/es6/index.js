const a = { name: "hehe" }; //

const b = a;

b.name = "kk";

console.log(a);
